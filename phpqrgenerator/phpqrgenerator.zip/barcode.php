<?php
// Permitir solicitudes desde cualquier origen
header('Access-Control-Allow-Origin: *');
// Permitir los encabezados X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
// Permitir los métodos GET, POST, OPTIONS, PUT, DELETE
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
// Permitir los métodos GET, POST, OPTIONS, PUT, DELETE
header("Allow: GET, POST, OPTIONS, PUT, DELETE");

// Si el método de solicitud es OPTIONS, terminar la ejecución aquí para evitar procesamiento adicional
$method = $_SERVER['REQUEST_METHOD'];
if ($method == "OPTIONS") {
    die();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generar códigos QR</title>
	<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link href="css/style.css" rel="stylesheet">	
	<link href="css/select2.css" rel="stylesheet"/>		
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="https://unpkg.com/sweetalert2@11.10.5/dist/sweetalert2.all.js"></script>
	<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>	
	<script src="js/select2.js"></script>
	<script src="js/ajax_generate_code.js"></script>
</head>
<body class="background">
    <?php
	if(isset($_POST['access_token']) && isset($_POST['estado'])) {
		// Obtengo los valores de los parámetros enviados desde Angular
		$access_token = $_POST['access_token'];
		$estado = $_POST['estado'];		
	?>
	
	<script>	
		var authtoken = "<?php echo $access_token; ?>";
		localStorage.setItem('authtoken', authtoken);			
		getRazonesSociales();
	</script>		
	
    <div class="container">
        <div class="form-container">
			<br/>
            <h2 class="text-center">Generar códigos QR</h2>
			<br/>
            <form class="form-horizontal" method="post" id="codeForm" onsubmit="return false">
			
				<div class="form-group">
					<div class="button-container">
						<button type="button" name="btnclose" id="btnclose" class="btn btn-link">
							<i class="fa fa-sign-out" aria-hidden="true"></i>
						</button>					
						<button type="button" name="btnreload" id="btnreload" class="btn btn-link">
							<i class="fa fa-refresh" aria-hidden="true"></i>
						</button>
						<button type="button" name="btnhistory" id="btnhistory" class="btn btn-link">
							<i class="fa fa-history" aria-hidden="true"></i>
						</button>						
					</div>
				</div>	
				<br/>							
				<div class="form-group">				    				    				
					<label for="empresas" class="textcolor">Razón Social:</label><br/>				
					<select class="form-control" id="empresas" name="empresas">
						<option value="">Seleccionar Razón Social</option>
					</select>
				</div>		
				<br/>											
				<div class="form-group">
					<label for="cantidad" class="textcolor">Cantidad de códigos QR a generar:</label>
					<input type="number" min="1" class="form-control" id="cantidad" value="1">
				</div>
				<br/>							
				<div class="accordion accordion-flush" id="accordionFlushExample">
				  <div class="accordion-item">
					<h2 class="accordion-header">
					  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
						Configuración del QR (Opcionales)
					  </button>
					</h2>
					<div id="flush-collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
					  <div class="accordion-body">
							<div class="form-group">
								<p for="size">Cantidad de columnas por página (2-5):</p>
								<input type="number" min="2" max="5" step="1" class="form-control" id="size" value="4">
							</div>			
							<div class="form-group">
								<p>URL Api punto de acceso</p>
								<input class="form-control" id="content" type="text" placeholder="https://freetags.com.ar/buscar" disabled>
							</div>
							<div class="form-group">
								<input type="checkbox" id="enableInput"> Editar url                    
							</div>
							<div class="form-group">
								<p for="ecc">Nivel del calidad código (QR):</p>
								<select class="form-control" id="ecc">
									<option value="H">1 - Alto</option>
									<option value="M">2 - Medio</option>
									<option value="Q">3 - Regular</option>
									<option value="L">4 - Bajo</option>
								</select>
							</div>					  
					  </div>
					</div>
				  </div>
				</div>				
				<hr/>
                <div class="form-group">
                    <input type="submit" name="submit" id="submit" class="btn btn-info btnlogin" value="Generar código QR">
                </div>
            </form>
            <div class="showQRCode"></div>
        </div>
    </div>
	
	<?php
    } else {
        // Redireccionar a la página de inicio de sesión
        //header("Location: index.html");
		header("Location: /"); // Redirige a la carpeta raíz del proyecto Angular.
    }
    ?>
	
</body>
</html>