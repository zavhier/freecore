$(document).ready(function() {
	
	//document.getElementById("btnloard").disabled = true;
	
	// Aca se setea la Url correspondiente a la ruta que se 
	// sera utilizada por la API para buscar en base a la informacion del códigos Qr
	// los datos del usuario.
	var urldefault = 'https://safebags.mysite.com.ar/buscar';
	
	
	getEmpresas();
	
	
    $("#codeForm").submit(function(){
				
	    if ($('#content').val() == "") {
			$('#content').val(urldefault);
	    }					
		
        $.ajax({
            url:'generate_code.php',
            type:'POST',
            data: {
                formData: $("#content").val(),
                ecc: $("#ecc").val(),
                size: $("#size").val(),
                cantidad: $("#cantidad").val()
            },
            success: function(response) {
				console.log(response);
                $(".showQRCode").html(response);  
            },
        });
    });
	
	
	$("#loginForm").submit(function(event) {
		event.preventDefault();

		if (($('#username').val() == "") || ($('#password').val() == "")) {
			alert("Usuario y clave son requeridos!");
		} else {
			var formData = new FormData();
			formData.append('username', $('#username').val());
			formData.append('password', $('#password').val());
			formData.append('company', '0');

			fetch('https://safebags.mysite.com.ar/api/index.php/auth', {
				method: 'POST',
				body: formData
			})
			.then(response => response.json())
			.then(data => {
				if (data.estado === 200 && data.data.access_token) {
					window.location.href = 'index.php?access_token=' + encodeURIComponent(data.data.access_token) + '&estado=200';
				} else {
					window.location.href = 'login.html';
				}
			})
			.catch(error => {
				console.error('Error:', error);
			});
		}
	});
	
    // Manejar el evento de cambio del checkbox
	// Habilitar o deshabilitar el input según el estado del checkbox
    $("#enableInput").change(function() {        
        $("#content").prop("disabled", !this.checked);
    });	
	
    // Manejador de evento para el botón btnloard
    $("#btnreload").click(function() {
		event.preventDefault();
		location.reload();
    });	

    // Manejador de evento para el botón btnloard
    $("#btnclose").click(function() {
		event.preventDefault();
		window.location.href = 'login.html';
    });	
	
});


function getEmpresas(){
            $.ajax({
                url: "empresas.php",
                type: "GET",
                success: function(data) {                    
                    var empresas = JSON.parse(data); // Parsear los datos de respuesta como JSON
                    var select = $("#empresas");
                    select.empty();
                    select.append($('<option></option>').attr('value', '').text('Seleccionar empresa'));
                    $.each(empresas, function(key, value) {
                        select.append($('<option></option>').attr('value', value.id).text(value.nombre));
                    });
                }
            });	
}


function loadDB() {
    // Código para cargar los Qr en la base de datos.
	dirpath = $('#inputDirname').val();
	
    alert("¡Botón presionado!" + dirpath);
}