<?php
// Creamos el archivo PDF con los códigos QR
require_once('fpdf186/fpdf.php'); // Incluimos la clase FPDF

require_once('phpqrcode/qrlib.php');


// Verificamos si se han enviado los datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturamos la URL y la cantidad de códigos QR
    $url = $_POST['url'];
    $cantidad = $_POST['cantidad'];

    // Creamos un array para almacenar los códigos QR generados
    $qr_codes = array();

    // Generamos códigos QR únicos para cada uno
    for ($i = 0; $i < $cantidad; $i++) {
        $codigo_unico = uniqid(); // Generamos un código alfanumérico único e irrepetible
        $codigo_completo = $url . '?code=' . $codigo_unico; // Concatenamos el código único a la URL

        // Creamos un archivo temporal para almacenar el código QR
	
        $file = tempnam(sys_get_temp_dir(), 'qr');

        QRcode::png($codigo_completo, $file, QR_ECLEVEL_L, 10);

        // Agregamos la ruta del archivo temporal al array de códigos QR
        $qr_codes[] = $file;
    }

	// Instanciamos la clase FPDF
	$pdf = new FPDF();
	$pdf->AddPage(); // Agregamos una página al PDF

	//$pdf->SetFont('Arial', 'B', 16); // Establecemos tipo de fuente, negrita y tamaño 16
	// Agregamos texto en una celda de 40px ancho y 10px de alto, Con Borde, Sin salto de línea y Alineada a la derecha
	//$pdf->Cell(40, 10, 'Hola, Mundo', 1, 0, 'L');

    // Configuramos el tamaño y la posición de los códigos QR en la página A4
    $x = 10; // Posición horizontal inicial
    $y = 10; // Posición vertical inicial
    $ancho_qr = 50; // Ancho de los códigos QR
    $alto_qr = 50; // Alto de los códigos QR
    $margen_x = 10; // Margen horizontal
    $margen_y = 10; // Margen vertical

    // Agregamos los códigos QR al PDF


    // Generamos el archivo PDF
    //$pdf->Output('I', 'codigos_qr.pdf'); // Mostramos el PDF en el navegador

    // Eliminamos los archivos temporales de los códigos QR
    //foreach ($qr_codes as $qr_code) {
    //    unlink($qr_code);
    //}	
	
	
	// Establecemos el tipo de contenido del encabezado para indicar que estamos enviando un archivo PDF
	header('Content-Type: application/pdf');

	// Utilizamos Output() con 'D' para mostrar el PDF en el navegador y sugerir un nombre de archivo para descargar
	$pdf->Output('HolaMundo.pdf', 'D');
	
}

?>