<?php
// Creamos el archivo PDF con los códigos QR
require_once('fpdf186/fpdf.php'); // Incluimos la clase FPDF

// Instanciamos la clase FPDF
$pdf = new FPDF();
$pdf->AddPage(); // Agregamos una página al PDF

$pdf->SetFont('Arial', 'B', 16); // Establecemos tipo de fuente, negrita y tamaño 16
// Agregamos texto en una celda de 40px ancho y 10px de alto, Con Borde, Sin salto de línea y Alineada a la derecha
$pdf->Cell(40, 10, 'Hola, Mundo', 1, 0, 'L');

// Establecemos el tipo de contenido del encabezado para indicar que estamos enviando un archivo PDF
header('Content-Type: application/pdf');

// Utilizamos Output() con 'D' para mostrar el PDF en el navegador y sugerir un nombre de archivo para descargar
$pdf->Output('HolaMundo.pdf', 'D');
?>