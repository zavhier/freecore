<?php 
if(isset($_POST) && !empty($_POST)) {
    include('phpqrcode/qrlib.php'); 
    $codesDir = "codes/";
    $formData = $_POST['formData'];
    $ecc = $_POST['ecc'];
    $size = $_POST['size'];
    $cantidad = $_POST['cantidad']; // Obtener la cantidad de códigos QR a generar

    // Generar la secuencia única e irrepetible de 8 caracteres alfanuméricos
    function generarSecuenciaUnica() {
        return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);
    }

    // Generar los códigos QR y mostrarlos en la página
    for ($i = 0; $i < $cantidad; $i++) {
        $codeFile = date('d-m-Y-h-i-s') . '-' . generarSecuenciaUnica() . '.png'; // Nombre del archivo con secuencia única
        QRcode::png($formData . '/' . generarSecuenciaUnica(), $codesDir.$codeFile, $ecc, $size);
        echo '<img class="img-thumbnail" src="'.$codesDir.$codeFile.'" />';
    }
} else {
    header('location:./');
}
?>