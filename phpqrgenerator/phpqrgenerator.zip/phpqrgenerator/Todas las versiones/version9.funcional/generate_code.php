<?php 
date_default_timezone_set("America/Argentina/Buenos_Aires");

if(isset($_POST) && !empty($_POST)) {
    include('phpqrcode/qrlib.php'); 
    
    $formData = $_POST['formData'];
    $ecc = $_POST['ecc'];
    $size = $_POST['size'];
    $cantidad = intval($_POST['cantidad']);
	
	$datetime = date('d-m-Y-h-i-s');	
	
	// Directorio base para alojar los Barcode QR.
	$codesDir = "codes/";   
	
	// Creo un directorio con la fecha actual.
	mkdir("codes/".$datetime, 0777);
	$codesDir = "codes/" . $datetime . "/"; 

	// Creo el nombre del archivo pdf salida.
	$pdfPath = 'codes/'.$datetime.'/codigos_qr.pdf';
	        

	//------------------------------------------------------------------------------------------------	
    // Genero los códigos QR
	//------------------------------------------------------------------------------------------------	
	$codeFiles = array();
    for ($i = 0; $i < $cantidad; $i++) {
		$keyuniq = generarSecuenciaUnica(8);
		$codeFile = $keyuniq .'.png';	
		// admite de 1-10, pero por defaul lo dejo en 5 porque el tamaño lo voy a manejar desde
		// la configuracion de la pagina.
		$sizebarcode = 5;     
        QRcode::png($formData . '/' . $keyuniq, $codesDir.$codeFile, $ecc, $sizebarcode);		
		
        $codeFiles[] = $codeFile;   // nombre del archivo png
		$codeQrTxt[] = $keyuniq;    // texto del qr
		
    }

	//------------------------------------------------------------------------------------------------	
    // Genero el contenido HTML para mostrar los códigos QR
	//------------------------------------------------------------------------------------------------	
    $html = '';
    //foreach ($codeFiles as $codeFile) {
    //    $html .= '<img class="img-thumbnail" src="'.$codesDir.$codeFile.'" /><br>';
    //}
    $html .= '<img class="img-thumbnail" src="'.$codesDir.$codeFiles[0].'" /><br>';
    
	// Agrego el enlace al PDF en el HTML
    $html .= '<a href="'.$pdfPath.'" target="_blank">Descargar PDF con los códigos QR</a>';

	
	//------------------------------------------------------------------------------------------------	
	// PDF:
	// Calculo el número de celdas que caben en una página A4 (210mm x 297mm) y dispongo
	// cada Código QR con su respectivo texto en cada celda.
	//------------------------------------------------------------------------------------------------		

    // Genero el archivo PDF con los códigos QR
    require_once('fpdf186/fpdf.php');

    // Instanciamos la clase FPDF
    $pdf = new FPDF();
    $pdf->AddPage(); // Agregamos una página al PDF
	
	// Configuración de la página A4
	$ancho_pagina = 210; // mm
	$alto_pagina = 297; // mm
	$margen_x = 10; // Margen horizontal en mm
	$margen_y = 10; // Margen vertical mm

	// Calcular el área útil de la página (descontando los márgenes)
	$ancho_util = $ancho_pagina - 2 * $margen_x;
	$alto_util = $alto_pagina - 2 * $margen_y;

	// Calcular el tamaño de la celda en función del espacio disponible y el número de columnas deseado
	$numero_columnas = $size; // Para ajustar la cantidad de columnas deseada

	$ancho_celda = $ancho_util / $numero_columnas;
	$alto_celda = $ancho_celda; // Para mantener la celda cuadrada

	// Calcular el número de filas necesario para acomodar todos los códigos QR
	$numero_filas = ceil(count($codeFiles) / $numero_columnas);

	// Inicializar las posiciones x e y para el primer código QR
	$x = $margen_x; // Posición horizontal inicial
	$y = $margen_y; // Posición vertical inicial

	// Iterar sobre cada fila y columna para dibujar los códigos QR
	$i = 0;
	foreach ($codeFiles as $codeFile) {
		// Agregar el código QR en la posición actual
		$pdf->Image($codesDir . $codeFile, $x, $y, $ancho_celda, $alto_celda);

		// Texto del codigo qr que se posicionara debajo de la imagen Qr
		$keyuniq = $codeQrTxt[$i];
		$i+=1;

		// Agregar el $keyuniq debajo de la imagen del código QR
		$pdf->SetXY($x+3, $y + $alto_celda);   // Posicionamos el texto debajo de la imagen
		$pdf->SetFont('Arial', '', 10);        // Establecemos la fuente y tamaño del texto
		$pdf->Cell(0, 9, $keyuniq, 0, 0, 'L'); // Agregamos el texto


		// Mover la posición horizontal a la siguiente columna
		$x += $ancho_celda;

		// Verificar si llegamos al final de la fila
		if ($x + $ancho_celda > $ancho_pagina - $margen_x) {			
			$x = $margen_x;         // Reiniciar la posición horizontal al principio de la fila			
			$y += $alto_celda + 10; // Mover la posición vertical a la siguiente fila
		}

		// Verificar si llegamos al final de la página
		if ($y + $alto_celda > $alto_pagina - $margen_y) {
			// Agregar una nueva página al PDF
			$pdf->AddPage();
			// Reiniciar las posiciones horizontal y vertical para la nueva página
			$x = $margen_x;
			$y = $margen_y;
		}
	}
	
    // Guardo el PDF en el servidor
    $pdfPath = 'codes/'.$datetime.'/codigos_qr.pdf';
    $pdf->Output($pdfPath, 'F'); // Guardamos el PDF en el servidor

    // Envia la respuesta    
	echo $html;
	
} else {
    header('location:./');
}

// Función para generar una cadena aleatoria de longitud $length
function generarSecuenciaUnica($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>