<?php 
date_default_timezone_set("America/Argentina/Buenos_Aires");

if(isset($_POST) && !empty($_POST)) {
    include('phpqrcode/qrlib.php'); 
    

    $formData = $_POST['formData'];
    $ecc = $_POST['ecc'];
    $size = $_POST['size'];
    $cantidad = intval($_POST['cantidad']);

	$datetime = date('d-m-Y-h-i-s');
	
	$codesDir = "codes/";   
	
	// Creo un directorio con la fecha actual.
	mkdir("codes/".$datetime, 0777);

	$codesDir = "codes/" . $datetime . "/"; 

    // Creo un array para almacenar los nombres de los archivos de los códigos QR generados
    $codeFiles = array();

    // Genero los códigos QR
    for ($i = 0; $i < $cantidad; $i++) {
		$keyuniq = generarSecuenciaUnica(8);
		$codeFile = $keyuniq .'.png';	
        QRcode::png($formData . '/' . $keyuniq, $codesDir.$codeFile, $ecc, $size);		
		
        $codeFiles[] = $codeFile;
    }

    // Genero el contenido HTML para mostrar los códigos QR
    $html = '';
    //foreach ($codeFiles as $codeFile) {
    //    $html .= '<img class="img-thumbnail" src="'.$codesDir.$codeFile.'" /><br>';
    //}
    $html .= '<img class="img-thumbnail" src="'.$codesDir.$codeFiles[0].'" /><br>';
	
    // Genero el archivo PDF con los códigos QR
    require_once('fpdf186/fpdf.php');

    // Instanciamos la clase FPDF
    $pdf = new FPDF();
    $pdf->AddPage(); // Agregamos una página al PDF

    // Configuro el tamaño y la posición de los códigos QR en la página A4
    $x = 10; // Posición horizontal inicial
    $y = 10; // Posición vertical inicial
    $ancho_qr = 50; // Ancho de los códigos QR
    $alto_qr = 50; // Alto de los códigos QR
    $margen_x = 10; // Margen horizontal
    $margen_y = 10; // Margen vertical

    // Agrego los códigos QR al PDF
    foreach ($codeFiles as $codeFile) {
        $pdf->Image($codesDir.$codeFile, $x, $y, $ancho_qr, $alto_qr);
        $x += $ancho_qr + $margen_x; // Movemos la posición horizontal
        // Si llego al borde derecho de la página, pasamos a la siguiente fila
        if ($x + $ancho_qr + $margen_x > $pdf->GetPageWidth()) {
            $x = 10; // Reseteamos la posición horizontal
            $y += $alto_qr + $margen_y; // Movemos la posición vertical
        }
        // Si llego al borde inferior de la página, agregamos una nueva página
        if ($y + $alto_qr + $margen_y > $pdf->GetPageHeight()) {
            $pdf->AddPage(); // Agregamos una nueva página al PDF
            $x = 10; // Reseteamos la posición horizontal
            $y = 10; // Reseteamos la posición vertical
        }
    }

    // Guardo el PDF en el servidor
    $pdfPath = 'codes/'.$datetime.'/codigos_qr.pdf';
    $pdf->Output($pdfPath, 'F'); // Guardamos el PDF en el servidor

    // Agrego el enlace al PDF en el HTML
    $html .= '<a href="'.$pdfPath.'" target="_blank">Descargar PDF con los códigos QR</a>';

    // Creo un array con el HTML y el nombre del PDF generado
    //$response = array(
    //    'html' => $html,
    //    'pdf' => $pdfPath
    //);

    // Envia la respuesta como JSON
    //echo json_encode($response);
	echo $html;
	
} else {
    header('location:./');
}

// Función para generar una cadena aleatoria de longitud $length
function generarSecuenciaUnica($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>