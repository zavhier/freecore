$(document).ready(function() {
	
	//document.getElementById("btnloard").disabled = true;
	
	// Aca se setea la Url correspondiente a la ruta que se 
	// sera utilizada por la API para buscar en base a la informacion del códigos Qr
	// los datos del usuario.
	var urldefault = 'https://safebags.mysite.com.ar/buscar';
	
    $("#codeForm").submit(function(){
				
	    if ($('#content').val() == "") {
			$('#content').val(urldefault);
	    }					
		
        $.ajax({
            url:'generate_code.php',
            type:'POST',
            data: {
                formData: $("#content").val(),
                ecc: $("#ecc").val(),
                size: $("#size").val(),
                cantidad: $("#cantidad").val()
            },
            success: function(response) {
				console.log(response);
                $(".showQRCode").html(response);  
				//document.getElementById("btnloard").disabled = false;
            },
        });
    });
	
    // Manejar el evento de cambio del checkbox
    $("#enableInput").change(function() {
        // Habilitar o deshabilitar el input según el estado del checkbox
        $("#content").prop("disabled", !this.checked);
    });	
	
    // Manejador de evento para el botón btnloard
    //$("#btnloadDB").click(function() {
	//	//event.preventDefault();
    //    alert("Directorio Repositorio: ");
    //});		
	
});


function loadDB() {
    // Código para cargar los Qr en la base de datos.
	dirpath = $('#inputDirname').val();
	
    alert("¡Botón presionado!" + dirpath);
}