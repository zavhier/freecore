$(document).ready(function() {
	
	//document.getElementById("btnloard").disabled = true;
	
	// Aca se setea la Url correspondiente a la ruta que se 
	// sera utilizada por la API para buscar en base a la informacion del códigos Qr
	// los datos del usuario.
	var urldefault = 'https://safebags.mysite.com.ar/buscar';
	
	
	//getEmpresas();
	
	
    $("#codeForm").submit(function(){
				
	    if ($('#content').val() == "") {
			$('#content').val(urldefault);
	    }					
		
        $.ajax({
            url:'generate_code.php',
            type:'POST',
            data: {
                formData: $("#content").val(),
                ecc: $("#ecc").val(),
                size: $("#size").val(),
                cantidad: $("#cantidad").val()
            },
            success: function(response) {
				//console.log(response);
                $(".showQRCode").html(response);  
            },
        });
    });
	
	
	$("#loginForm").submit(function(event) {
		event.preventDefault();

		if (($('#username').val() == "") || ($('#password').val() == "")) {
			alert("Usuario y clave son requeridos!");
		} else {
			var formData = new FormData();
			formData.append('username', $('#username').val());
			formData.append('password', $('#password').val());
			formData.append('company', '0');

			fetch('https://safebags.mysite.com.ar/api/index.php/auth', {
				method: 'POST',
				body: formData
			})
			.then(response => response.json())
			.then(data => {
				if (data.estado === 200 && data.data.access_token) {
					window.location.href = 'index.php?access_token=' + encodeURIComponent(data.data.access_token) + '&estado=200';
				} else {
					window.location.href = 'login.html';
				}
			})
			.catch(error => {
				console.error('Error:', error);
			});
		}
	});
	
    // Manejar el evento de cambio del checkbox
	// Habilitar o deshabilitar el input según el estado del checkbox
    $("#enableInput").change(function() {        
        $("#content").prop("disabled", !this.checked);
    });	
	
    // Manejador de evento para el botón btnloard
    $("#btnreload").click(function() {
		event.preventDefault();
		location.reload();
    });	

    // Manejador de evento para el botón btnloard
    $("#btnclose").click(function() {
		event.preventDefault();
		window.location.href = 'login.html';
    });	
	
});


function getEmpresas(){
	
	var token = localStorage.getItem('authtoken');
	
	fetch('https://safebags.mysite.com.ar/api/index.php/productype',{
		headers: {
			'Authorization': 'Bearer ' + token
		}	
	})
		.then(response => response.json())
		.then(data => {
			if (data.estado === 200) {
				var empresas = data.data;
				var select = $("#empresas");

				// Limpiar el select
				select.empty();

				// Agregar la opción predeterminada
				select.append($('<option></option>').attr('value', '').text('Seleccionar empresa'));

				// Agregar las opciones de empresas
				empresas.forEach(empresa => {
					select.append($('<option></option>').attr('value', empresa.id).text(empresa.descripcion));
				});
			} else {
				console.error('Error al obtener los datos de empresas.');
			}
		})
		.catch(error => {
			console.error('Error:', error);
		});
}


//function loadDB_OK() {
//	
//	var token = localStorage.getItem('authtoken');
//	
//    // Código para cargar los Qr en la base de datos.
//	dirpath = $('#inputDirname').val();
//	
//    alert("¡Botón presionado!" + dirpath);
//	
//	// Ruta del archivo de texto
//	const rutaArchivo = dirpath + '/codigos_qr.txt';
//
//	// Realizar una petición AJAX para obtener el contenido del archivo
//	fetch(rutaArchivo)
//		.then(response => {
//			if (!response.ok) {
//				throw new Error('Error al cargar el archivo');
//			}
//			return response.text();
//		})
//		.then(contenido => {
//			// Dividir el contenido en líneas y crear un array
//			const lineas = contenido.split('\n');
//			const array = lineas.map(linea => linea.trim());
//			
//			// Crear un objeto FormData y agregar el array como campo
//			const formData = new FormData();
//			formData.append('barcodes', array.join(',')); 
//
//			//for (const elemento of array) {
//			//	console.log(elemento); 
//			//}
//
//			// Enviar el FormData mediante fetch
//			fetch('https://safebags.mysite.com.ar/api/index.php/producsavebcqr', {
//				method: 'POST',
//				body: formData,
//				headers: {
//					'Authorization': 'Bearer ' + token
//				}				
//			})
//			.catch(error => {
//				console.error('Error al enviar el FormData:', error);
//			});
//		})
//		.catch(error => {
//			console.error('Error al cargar el archivo: ' + rutaArchivo, error);
//		});	
//	
//}


function loadDB() {
	
	var token = localStorage.getItem('authtoken');
		    
	dirpath = $('#inputDirname').val(); // Código para cargar los Qr en la base de datos.
			
	const rutaArchivo = dirpath + '/codigos_qr.txt';  // Ruta del archivo de texto

	// AJAX para obtener el contenido del archivo
	fetch(rutaArchivo)
		.then(response => {
			if (!response.ok) {
				throw new Error('Error al cargar el archivo');
			}
			return response.text();
		})
		.then(contenido => {
			// Dividir el contenido en líneas y crear un array
			const lineas = contenido.split('\n');
			const array = lineas.map(linea => linea.trim());
			
			// Crear un objeto FormData y agregar el array como campo
			const formData = new FormData();
			formData.append('barcodes', array.join(',')); 
			
			// Crear un objeto JSON con los datos del array
			  const jsonData = { datos: array.join(',') , "idRazonSocial":9, "url_qr":"www.freetags.com.ar/buscar/d66eed33", "urlimg": dirpath };			

			//for (const elemento of array) {
			//	console.log(elemento); 
			//}

			// Enviar el FormData mediante fetch
			fetch('https://safebags.mysite.com.ar/api/index.php/productsuploadqr', {
				method: 'POST',
				body: JSON.stringify(jsonData),
				headers: {
					'Content-Type': 'application/json',
					'Authorization': 'Bearer ' + token
				}				
			})
			.catch(error => {
				console.error('Error al enviar el FormData:', error);
			});					
		})
		.catch(error => {
			console.error('Error al cargar el archivo: ' + rutaArchivo, error);
		});	
	
}
