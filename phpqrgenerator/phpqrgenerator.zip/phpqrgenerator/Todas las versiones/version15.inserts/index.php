<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generar códigos QR</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script src="ajax_generate_code.js"></script>
	<link rel="stylesheet" href="style.css">	
</head>
<body>
    <?php
    if (!empty($_GET['access_token']) && $_GET['estado'] == 200) {
	?>
	
	<script>
		var authtoken = "<?php echo $_GET['access_token']; ?>";
		localStorage.setItem('authtoken', authtoken);
		getEmpresas();
	</script>		
	
    <div class="container">
        <div class="form-container">
            <h2 class="text-center">Generar códigos QR</h2>
			<br/>
            <form class="form-horizontal" method="post" id="codeForm" onsubmit="return false">
			
				<div class="form-group">
					<div class="button-container">
						<button type="button" name="btnreload" id="btnreload" class="btn btn-link">
							<span class="glyphicon glyphicon-refresh glyphicon-refresh-animate"></span>
						</button>
						<button type="button" name="btnclose" id="btnclose" class="btn btn-link">
							<span class="glyphicon glyphicon-log-out"></span>
						</button>
					</div>
				</div>	
				
				<div class="form-group">
					<label for="empresas" class="textcolor">Empresa:</label>
					<select class="form-control" id="empresas" name="empresas">
						<option value="">Seleccionar empresa</option>
					</select>
				</div>		
				<div class="form-group">
					<label for="cantidad" class="textcolor">Cantidad de códigos QR a generar:</label>
					<input type="number" min="1" class="form-control" id="cantidad" value="1">
				</div>
				<hr/>
                <div class="form-group">
                    <label for="content">Configuración del QR (Opcionales)</label>
                </div>
                <div class="form-group">
                    <p for="size">Cantidad de columnas por página (2-5):</p>
                    <input type="number" min="2" max="5" step="1" class="form-control" id="size" value="4">
                </div>				
                <div class="form-group">
                    <input class="form-control" id="content" type="text" placeholder="https://freetags.mysite.com.ar/buscar" disabled>
                </div>
                <div class="form-group">
                    <input type="checkbox" id="enableInput"> Editar repositorio                    
                </div>
                <div class="form-group">
                    <p for="ecc">Nivel del calidad código (QR):</p>
                    <select class="form-control" id="ecc">
                        <option value="H">1 - Alto</option>
                        <option value="M">2 - Medio</option>
                        <option value="Q">3 - Regular</option>
                        <option value="L">4 - Bajo</option>
                    </select>
                </div>
				<hr/>
                <div class="form-group">
                    <input type="submit" name="submit" id="submit" class="btn btn-success" value="Generar código QR">
                    <!-- <button type="button" name="loarddb" id="btnloard" class="btn btn-info" disabled>Cargar Códigos</button> -->
                </div>
            </form>
            <div class="showQRCode"></div>
        </div>
    </div>
	
	<?php
    } else {
        // Redireccionar a la página de inicio de sesión
        header("Location: login.html");
    }
    ?>
	
</body>
</html>