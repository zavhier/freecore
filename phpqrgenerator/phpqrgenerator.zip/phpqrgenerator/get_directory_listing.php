<?php

// Ruta del directorio a escanear
$directory = 'codes';

// Función para obtener el listado de directorios y archivos
function getDirectoryListing($directory) {
    $result = array();

    // Verificar si el directorio es accesible
    if (is_dir($directory) && is_readable($directory)) {
        // Escanear el directorio
        $files = scandir($directory);

        // Iterar sobre los archivos y directorios
        foreach ($files as $file) {
            // Excluir directorios "." y ".."
            if ($file != '.' && $file != '..') {
                // Comprobar si es un directorio
                if (is_dir($directory . '/' . $file)) {
                    // Agregar el directorio al resultado
                    $result[] = array(
                        'name' => $file,
                        'type' => 'directory'
                    );
                } elseif (basename($file) == 'codigos_qr.pdf') {
                    // Si es un archivo PDF llamado "codigos_qr.pdf", agregarlo al resultado
                    $result[] = array(
                        'name' => $file,
                        'type' => 'file'
                    );
                }
            }
        }
    }

    return $result;
}

// Obtener el listado de directorios y archivos
$directoryListing = getDirectoryListing($directory);

// Devolver el listado como JSON
header('Content-Type: application/json');
echo json_encode($directoryListing);