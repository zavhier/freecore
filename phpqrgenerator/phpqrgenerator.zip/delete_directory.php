<?php
// Verificar si se recibió el nombre del directorio a eliminar
if (isset($_POST['directory'])) {
    // Directorio a eliminar
    $directory = $_POST['directory'];

    // Ruta completa del directorio a eliminar
    $directoryPath = __DIR__ . '/codes/' . $directory;

    // Función recursiva para eliminar un directorio y su contenido
    function deleteDirectory($dir) {
        if (!file_exists($dir)) {
            return true;
        }
        if (!is_dir($dir) || is_link($dir)) {
            return unlink($dir);
        }
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . "/" . $item)) {
                chmod($dir . "/" . $item, 0777);
                if (!deleteDirectory($dir . "/" . $item)) return false;
            };
        }
        return rmdir($dir);
    }

    // Intentar eliminar el directorio y su contenido
    if (deleteDirectory($directoryPath)) {
        // Si se elimina con éxito, enviar una respuesta exitosa
        echo json_encode(array('success' => true));
    } else {
        // Si hay algún error al eliminar el directorio, enviar una respuesta de error
        echo json_encode(array('success' => false, 'message' => 'Error al eliminar el directorio.'));
    }
} else {
    // Si no se proporciona el nombre del directorio, enviar una respuesta de error
    echo json_encode(array('success' => false, 'message' => 'No se proporcionó el nombre del directorio.'));
}
?>