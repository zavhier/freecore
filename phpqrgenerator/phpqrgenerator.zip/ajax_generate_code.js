
// Aca setear el acceso la ruta de acceso a la API.
var URL_API = "https://safebags.mysite.com.ar/api/index.php";; 

// Aca se setea la Url correspondiente a la ruta que sera 
// utilizada por la API para buscar en base a la informacion del códigos Qr
// los datos del usuario. Es decir que esta url viajara dentro del codigo Qr.
// Importante: esta url tambien hay que ponerla como placeholder en index.php.
var ACCESS_POINT = 'https://safebags.mysite.com.ar/buscar';


$(document).ready(function() {
		
    $("#codeForm").submit(function(){
				
	    if ($('#content').val() == "") {
			$('#content').val(ACCESS_POINT);
	    }					
		
        $.ajax({
            url:'generate_code.php',
            type:'POST',
            data: {
                formData: $("#content").val(),
                ecc: $("#ecc").val(),
                size: $("#size").val(),
                cantidad: $("#cantidad").val()
            },
            success: function(response) {
				//console.log(response);
                $(".showQRCode").html(response);  
            },
        });
    });
	
	
	$("#loginForm").submit(function(event) {
		event.preventDefault();

		if (($('#username').val() == "") || ($('#password').val() == "")) {
			alert("Usuario y clave son requeridos!");
		} else {
			var formData = new FormData();
			formData.append('username', $('#username').val());
			formData.append('password', $('#password').val());
			formData.append('company', '0');

			fetch(URL_API + '/auth', {
				method: 'POST',
				body: formData
			})
			.then(response => response.json())
			.then(data => {
				if (data.estado === 200 && data.data.access_token) {
					window.location.href = 'index.php?access_token=' + encodeURIComponent(data.data.access_token) + '&estado=200';
				} else {
					window.location.href = 'login.html';
				}
			})
			.catch(error => {
				console.error('Error:', error);
			});
		}
	});
	
    // Manejar el evento de cambio del checkbox
	// Habilitar o deshabilitar el input según el estado del checkbox
    $("#enableInput").change(function() {        
        $("#content").prop("disabled", !this.checked);
    });	
	
    // Manejador de evento para el botón btnloard
    $("#btnreload").click(function() {
		event.preventDefault();
		location.reload();
    });	

    // Manejador de evento para el botón btnloard
    $("#btnclose").click(function() {
		event.preventDefault();
		window.location.href = 'login.html';
    });	
	
});


function getRazonesSociales(){
	
	var token = localStorage.getItem('authtoken');
	
	fetch(URL_API + '/socialreason',{
		headers: {
			'Authorization': 'Bearer ' + token
		}	
	})
		.then(response => response.json())
		.then(data => {
			if (data.estado === 200) {
				var empresas = data.data;
				var select = $("#empresas");

				// Limpiar el select
				select.empty();

				// Agregar la opción predeterminada
				select.append($('<option></option>').attr('value', '').text('Seleccionar empresa'));

				// Agregar las opciones de empresas
				empresas.forEach(empresa => {
					select.append($('<option></option>').attr('value', empresa.id).text(empresa.nombre));
				});
			} else {
				console.error('Error al obtener los datos de empresas.');
			}
		})
		.catch(error => {
			console.error('Error:', error);
		});
}

function loadDB() {
	
	var idRazonSocial = $('#empresas').val();
	var urlContent = $('#content').val();
	var token = localStorage.getItem('authtoken');
		    
	// Ruta del archivo de texto que contiene lso Qr cuya informacion sera en viada a la api.
	dirpath = $('#inputDirname').val(); 
	const rutaArchivo = dirpath + '/codigos_qr.txt';  

	if (idRazonSocial) {
		// AJAX para obtener el contenido del archivo
		fetch(rutaArchivo)
			.then(response => {
				if (!response.ok) {
					throw new Error('Error al cargar el archivo');
				}
				return response.text();
		})
			.then(contenido => {
				// Dividir el contenido en líneas y crear un array
				const lineas = contenido.split('\n');
				const array = lineas.map(linea => linea.trim());
				//for (const elemento of array) {
				//	console.log(elemento); 
				//}				
				
				// Crear un objeto FormData y agregar el array como campo
				const formData = new FormData();
				formData.append('barcodes', array.join(',')); 
				
				// Crear un objeto JSON con los datos del array
				const jsonData = { 
					datos: array.join(',') , "idRazonSocial":idRazonSocial, "url_qr":urlContent, "urlimg": dirpath 
				};			

				// AJAX para enviar el el Json con los Qr.
				fetch(URL_API + '/productsuploadqr', {
					method: 'POST',
					body: JSON.stringify(jsonData),
					headers: {
						'Content-Type': 'application/json',
						'Authorization': 'Bearer ' + token
					}				
				})
				.then(response => response.json())
				.then(json => {
					if(json.estado == 200){
						alert("Los códigos QR fueron cargados con éxito!");
						location.reload();
					}
				})	
				.catch(error => {
					console.error('Error al intentar insertar nuevos registros (QR) en la tabla productos:', error);
				});					
			})
			.catch(error => {
				console.error('Error al cargar el archivo: ' + rutaArchivo + ' para la carga de Códigos QR en base.', error);
			});	
	}else{
		alert("Para continiar, es necesario seleccionar una RAZON SOCIAL!");
	}
}
